By Leo Blanchette

Improve, modify and distrubute. Credit when possible. 

About the tower:
http://en.wikipedia.org/wiki/Wardenclyffe_Tower

The Model Tower video preview:
http://www.youtube.com/watch?v=Y0NADbxAOo8
http://www.youtube.com/watch?v=-v2g0Yrpu-Q

My website: 
http://www.clipartillustration.com/

Are you a 3d modeller? Sell your images direct to customer via Symbiostock, 
Another free resource by Leo Blanchette
http://www.symbiostock.com/
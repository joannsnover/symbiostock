<?php

add_action( 'after_setup_theme', 'ss_extend_cart' );

function ss_extend_cart(){
	
	//if class does not exist, that means theme is not installed...and we kill the plugin
	if(!class_exists('symbiostock_cart')){		
		// Include the plugin.php file so you have access to the activate_plugin() function
		require_once(ABSPATH .'/wp-admin/includes/plugin.php');
		
		require_once(ABSPATH .'/wp-admin/includes/file.php');
		
		$symbiostock_plugin_path = ABSPATH . 'wp-content/plugins/';
	
		$symbiostock_plugin =  dirname(__FILE__) . '/ss-cart-manager.php';
		
		deactivate_plugins($symbiostock_plugin);
		
		return;
	}
	
	class ss_manage_cart extends symbiostock_cart{
		  
		function __construct( $user )
		{			
			parent::__construct($user);
				
			$this->user = $user;	
			
			$this->option_count = 0;
			
			//get or set up our cart
			$current_cart = get_user_meta( $this->user->ID, 'symbiostock_cart', true );
			
			if ( !empty( $current_cart ) ) {
			//for testing, uncomment next line
			//update_user_meta($this->user, 'symbiostock_cart', '');
			
			$this->cart = unserialize( get_user_meta( $this->user->ID, 'symbiostock_cart', true ) );
			
			} else {
				//if we don't have a cart, initiate one
				$this->cart_template();
				update_user_meta( $this->user->ID, 'symbiostock_cart', serialize( $this->cart ) );
				
			}
			//var_dump($this->user);
					
		}
		
		public function get_cart_date(){
			if(isset($this->cart['date'])){
				return $this->cart['date'];
			}else{
				return 'Date not included';
				}
			}
		
		public function display_manage_customer_cart( )
    {
				
		$curr = $this->currency();
		$cart_items = $this->cart['products'];
				
		$email = $this->cart['cart_email'];		
		
		$paypal_vars = htmlspecialchars(serialize($paypal_vars));
		?>        
        
       <table class="widefat">
        <thead>
            <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col">
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Preview</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Option</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Price - <?php echo $curr[0]; ?></th> 
            <th id="columnname" class="manage-column column-columnname" scope="col">&nbsp;</th>                   
        </thead>
        <tbody>
        
       	<?php
		$product_count = 0;
		
		foreach($cart_items as $product => $info){
			
			$product_count++;
			
			//gather relevant data
			
			$product_info = symbiostock_post_meta($product);
			
			$price = $this->calc_discount($info['price'], $product_info['discount_percent'][0]);
						
			$sizes = (unserialize($product_info['size_info'][0]));
								
			$minipic = '<a title="" href="' . get_permalink( $product ) . '"><img width="' . $sizes['thumb']['width'] . '" height="' . $sizes['thumb']['height'] . '" alt="img ' . $product . '" src="' . $product_info['symbiostock_minipic'][0] . '" /></a>';
			
			$size_info = unserialize($product_info['size_info'][0]);
			
			$size_name = $info['size_name'];
			
			$option = '<strong>' .$product . '</strong><br /><br /><strong>' . $info['type'] . ', ' . ucwords($info['size_name']) . '</strong><br />' . $size_info[$size_name]['pixels'] . '<br />' . $size_info[$size_name]['dpi'] ;
			
			//make the row	?>										
            <tr>
            <th class="check-column" scope="row">
                <label class="screen-reader-text" for="cb-select-<?php echo $product;  ?>">Select Cart</label>
                <input id="cb-select-<?php echo $cart->ID; ?>" type="checkbox" value="<?php echo $product; ?>" name="ssimage[]">
            </th>           
            <?php 
			echo '<td>' . $minipic . '</td><td>' . $option  . '</td><td class="price">' . $curr[1] . $price['compare'] . '</td><td><a id="remove_' . $product . '" class="remove_from_cart" href="#"><i class="icon-remove-sign">&nbsp;</i></a></td>'; ?> 
			</tr>
            <?php
		}
		
		?>       
            </tbody>
            <tfoot>
                <tr>
                    <th id="cb" class="manage-column column-cb check-column" scope="col">
                        <label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                        <input id="cb-select-all-1" type="checkbox">
                    </th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Preview</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Option</th>
                    <th id="columnname" class="manage-column column-columnname" scope="col">Price - <?php echo $curr[0]; ?></th> 
                    <th id="columnname" class="manage-column column-columnname" scope="col">&nbsp;</th>  
                </tr>
            </tfoot>
        </table>
         
        <?php
		
    }	
	
	}
	
}


function ss_cart_actions(){
	

	switch($_POST['ss_action']){
		
		case 'approve_to_download':
			
			foreach($_POST['sscart'] as $cart_id){	
			
				//file_put_contents('test.txt', print_r($user_products, true));
				//update_user_meta($cart_id, 'symbiostock_purchased_products', '');				
				
				$user = get_userdata($cart_id); 	
				
				$user_products = get_user_meta($cart_id, 'symbiostock_purchased_products'); 
													
				$user_cart = new ss_manage_cart($user);
				
				$user_products = unserialize($user_products[0]); //shift the array over
				
				$user_cart->cart['products'];
								
				foreach($user_cart->cart['products'] as $number => $product_info){	
								
					$user_products[$number]=$product_info;			
				
				}				
							
				update_user_meta($cart_id, 'symbiostock_purchased_products', serialize($user_products));
				
			}	
			
					
			break;	

		case 'delete_cart':
		
			foreach($_POST['sscart'] as $cart_id){	
		
				$user = get_userdata($cart_id); 
				
				update_user_meta($cart_id, 'symbiostock_cart', '');	
				
			}
		
		
			break;					
		
		}
	
	}



function ss_cart_to_download(){
			
		foreach($user_cart->cart['products'] as $number => $product_info){	
				
			$user_products[$number]=$product_info;			
			
		}
	}

//gets all user's carts. 
function ss_get_user_carts(){
	global $wpdb;
	
	$carts = $wpdb->get_results("
		SELECT u.ID, u.display_name, u.user_email, um.meta_value AS cart
		FROM $wpdb->users u
		JOIN $wpdb->usermeta um ON um.user_id = u.ID
		WHERE um.meta_key = 'symbiostock_cart'
		ORDER by um.meta_value
		ASC"
	);

 	return $carts;
}
//gets all user's purchases. 
function ss_get_user_purchases(){
	global $wpdb;
	
	$carts = $wpdb->get_results("
		SELECT u.ID, u.display_name, u.user_email, um.meta_value AS purchases
		FROM $wpdb->users u
		JOIN $wpdb->usermeta um ON um.user_id = u.ID
		WHERE um.meta_key = 'symbiostock_purchased_products'
		ORDER by um.meta_value
		ASC"
	);

 	return $carts;
}

function ss_get_products($info){
	
	if(isset($info->purchases)){		
		$user_items = unserialize(unserialize($info->purchases));	
	}
		else
	{
		$user_items = unserialize(unserialize($info->cart));
		$user_items = $user_items['products'];
	}	

	return $user_items;
	}

function ss_display_user_files(){
	?>
    <table class="widefat fixed" cellspacing="0">
    <thead>
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col">
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Number</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Type</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Size</th>
        </tr>
    </thead>
    <tfoot>    
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col"> 
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Number</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Type</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Size</th>
        </tr>
    </tfoot>  
    <?php
	$current_user = get_userdata($_GET['ss_cart']);
	
	$user_products = symbiostock_get_user_files($current_user->ID);
	
	foreach($user_products as $product => $info){

		//gather relevant data
		
		$product_info = symbiostock_post_meta($product);			
					
		$sizes = unserialize($product_info['size_info'][0]);
								
		?>  <tr>
                <th class="check-column" scope="row">
                    <label class="screen-reader-text" for="cb-select-<?php echo $purchase->ID;  ?>">Select Cart</label>
                    <input id="cb-select-<?php echo $purchase->ID; ?>" type="checkbox" value="<?php echo $product; ?>" name="sspurchases[]">
                </th>
                <td>
                	<?php echo '<img width="' . $sizes['thumb']['width'] . '" height="' . $sizes['thumb']['height'] . '" alt="img ' . $product . '" src="' . $product_info['symbiostock_minipic'][0] . '" />'; ?>
                </td>             
                <td>
                	<?php echo $product; ?>
                </td>
                <td>
                	<?php echo $info['type']; ?>
                </td>
                <td>
					<?php echo $info['size_name']; ?>
                </td>
            </tr>      
        <?php			
		}
	?>
    </table>
    <?php
}

function ss_display_user_purchases(){

?>
<table class="widefat fixed" cellspacing="0">
    <thead>
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col">
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Email</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Items</th>
        </tr>
    </thead>
    <tfoot>    
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col"> 
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Email</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Items</th>
        </tr>
    </tfoot>    
	<?php	
	$purchases = ss_get_user_purchases();
	
		foreach($purchases as $purchase){
			
			$products = ss_get_products($purchase);
			
			$cart_functions = new ss_manage_cart($purchase);
			
			if(empty($products))
				continue;
			
			$cart_count++;
			
			$see_purchases = add_query_arg(array('ss_cm'=>'get_purchases', 'ss_cart'=>$purchase->ID));		
			
		?>  <tr>
                <th class="check-column" scope="row">
                    <label class="screen-reader-text" for="cb-select-<?php echo $purchase->ID;  ?>">Select Cart</label>
                    <input id="cb-select-<?php echo $purchase->ID; ?>" type="checkbox" value="<?php echo $purchase->ID; ?>" name="sspurchases[]">
                </th>
                <td>
                	<a title="See products..." href="<?php echo $see_purchases; ?>"><?php echo $purchase->display_name;	?></a>
                </td>
                <td>
                	<a title="<?php echo $purchase->display_name; ?>" href="mailto:<?php echo $purchase->user_email; ?>"><?php echo $purchase->user_email; ?></a>
                </td>
                <td>
					<a title="See products..." href="<?php echo $see_purchases; ?>"><?php echo count($products); ?></a>
                </td>
            </tr>      
        <?php
		unset($cart_functions);				
        }
	?>
</table>
<?php	
}
	
function ss_display_user_carts(){
	
	//check actions and update cart or files...
	ss_cart_actions();
				
	$cart_count=1;
	?>

<table class="widefat fixed" cellspacing="0">
    <thead>
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col">
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Email</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Cart Value / Items</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Cart Date</th>
        </tr>
    </thead>
    <tfoot>    
        <tr>
            <th id="cb" class="manage-column column-cb check-column" scope="col"> 
            	<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1" type="checkbox">
            </th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Email</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Cart Value / Items</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Cart Date</th>
        </tr>
    </tfoot>
    <?php
		
		$carts = ss_get_user_carts();			
	
		foreach($carts as $cart){
			
			$products = ss_get_products($cart);
			$cart_functions = new ss_manage_cart($cart);
			
			if(empty($products))
				continue;
			
			$cart_count++;	
			
			$see_cart = add_query_arg(array('ss_cm'=>'get_cart', 'ss_cart'=>$cart->ID));
			
		?>  <tr>
                <th class="check-column" scope="row">
                    <label class="screen-reader-text" for="cb-select-<?php echo $cart->ID;  ?>">Select Cart</label>
                    <input id="cb-select-<?php echo $cart->ID; ?>" type="checkbox" value="<?php echo $cart->ID; ?>" name="sscart[]">
                </th>
                <td>
                	<a title="See cart..." href="<?php echo $see_cart; ?>"><?php echo $cart->display_name;	?></a>
                </td>
                <td><a title="<?php echo $cart->display_name; ?>" href="mailto:<?php echo $cart->user_email; ?>"><?php echo $cart->user_email; ?></a></td>
                <td>
					<a title="See cart..." href="<?php echo $see_cart; ?>"><?php echo $cart_functions->get_cart_value() . ' (' . count($products) . ')'; ?></a>
                </td>
                <td>
                <?php 
				echo $cart_functions->get_cart_date();
				?>
                </td>
            </tr>      
        <?php
		unset($cart_functions);				
        }
	?>
</table>

<br />
<select name="ss_action">
	<option value="-">-</option>
	<option value="approve_to_download">Approve to Download</option>
    <option value="delete_cart">Delete Cart</option>	
</select>
<?php
	
	}

function ss_cart_manager_base_menu(){
	
	$carts_link = add_query_arg(array('ss_cm'=>'carts'));
	
	$purchased_link = add_query_arg(array('ss_cm'=>'purchased'));
	
	?>    
    <a title="See all carts" href="<?php echo $carts_link ?>">See All Carts</a> &bull; 
    <a title="See all purchases" href="<?php echo $purchased_link ?>">See All Purchases</a>   
    <?php
	}	
	
function ss_display_user_cart(){
	$user = get_userdata($_GET['ss_cart']);
	$cart_functions = new ss_manage_cart($user);
	$cart_functions->display_manage_customer_cart();
	
}
?>
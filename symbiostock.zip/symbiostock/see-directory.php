<div class="well alert alert-info ">                
    <span class="alignleft"><?php echo symbiostock_directory_link($text = '', false, false) ?></span>
    
    <h3><?php _e('Extended Network Directory', 'symbiostock') ?></h3>                   
    
    <p class="text-info"><?php _e('See the page for more sites / authors. ', 'symbiostock') ?> <strong><a title="<?php _e('Symbiostock Directory', 'symbiostock') ?>" href="<?php echo symbiostock_directory_link($text = '', true) ?>" ><?php _e('Symbiostock Directory', 'symbiostock') ?></a> </strong></p>
    <div class="clearfix"><br /></div>
</div>
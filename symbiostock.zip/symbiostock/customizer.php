<?php 

add_theme_support( 'custom-background' );


function symbiostock_customize_register( $wp_customize ) {

    //NAV MENU
 
    $wp_customize->add_section( 'symbiostock_nav_menu' , array(
            'title'      => __( 'Symbiostock Nav Menu', 'symbiostock' ),
            'priority'   => 34,
    ) );

    $wp_customize->add_setting( 'menu_location' , array(
            'default'     => '0',
            
    ) );    
    
    $wp_customize->add_control( 'menu_location', array(
            'label'        => __( 'Menu Location', 'symbiostock' ),
            'type'       => 'radio',
            'choices' => array(
                    '0' => 'Top Anchored',
                    '1' => 'Under Header'                    
            ),            
            'section'    => 'symbiostock_nav_menu',
            'settings'   => 'menu_location',
    ) );
    
    $wp_customize->add_setting( 'show_blog_search' , array(
            'default'     => '1',
    
    ) );
    
    $wp_customize->add_control( 'show_blog_search', array(
            'label'        => __( 'Show "Image/Blog" search option?', 'symbiostock' ),
            'type'       => 'radio',
            'choices' => array(
                    '1' => 'Yes',
                    '0' => 'No'
            ),
            'section'    => 'symbiostock_nav_menu',
            'settings'   => 'show_blog_search',
    ) );    
    
    //GENERAL 
    $wp_customize->add_section( 'symbiostock_general' , array(
        'title'      => __( 'Symbiostock General', 'symbiostock' ),
        'priority'   => 35,
    ) );

    
    
    $wp_customize->add_setting( 'background_color' , array(
            'default'     => '#fff',
            'transport'   => 'postMessage',
    ) );    
    
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'background_color', array(
            'label'        => __( 'Background Color', 'symbiostock' ),
            'section'    => 'symbiostock_general',
            'settings'   => 'background_color',
    ) ) ); 


    //H COLOR
    $wp_customize->add_setting( 'h_color' , array(
            'default'     => '#333',
            'transport'   => 'postMessage',
    ) );
    
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'h_color', array(
            'label'        => __( 'Content/Header Color', 'symbiostock' ),
            'section'    => 'symbiostock_general',
            'settings'   => 'h_color',
    ) ) );    
    
    //P COLOR
    $wp_customize->add_setting( 'p_color' , array(
            'default'     => '#333',
            'transport'   => 'postMessage',
    ) );
    
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'p_color', array(
            'label'        => __( 'Content/Paragraph Color', 'symbiostock' ),
            'section'    => 'symbiostock_general',
            'settings'   => 'p_color',
    ) ) );    
    
    /*
     * Image Page Related Stuff
    */    

    $wp_customize->add_section( 'symbiostock_image_page' , array(
            'title'      => __( 'Symbiostock Image Page', 'symbiostock' ),
            'priority'   => 36,
    ) );

    $wp_customize->add_setting( 'widget_background_color' , array(
            'default'     => '#ccc',
            'transport'   => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'widget_background_color', array(
            'label'        => __( 'Widget Background Color', 'symbiostock' ),
            'section'    => 'symbiostock_image_page',
            'settings'   => 'widget_background_color',
    ) ) );    
    
}
add_action( 'customize_register', 'symbiostock_customize_register' );

function symbiostock_customize_css()
{
    ?>
    <style type="text/css">  
    
     body { 
     background-color:#<?php echo get_theme_mod('background_color'); ?>; 
     }
     
     .type-image .front-page-featured { 
     background-color:#<?php echo get_theme_mod('widget_background_color'); ?>; 
     }
           
     .symbiostock_branding
     {
         background-image: url(<?php echo header_image(); ?>); 
         background-repeat: no-repeat;
     }   
     
     h1, h2, h3, h4, h5, h6,
     h1 a:link, h2 a:link, h3 a:link, h4 a:link, h5 a:link, h6 a:link, 
      {
     color: <?php echo get_theme_mod('h_color'); ?>;
     }
     
     p {
     color: <?php echo get_theme_mod('p_color'); ?>;
     }
     
    </style>
    <?php
}
add_action( 'wp_head', 'symbiostock_customize_css');

/**
 * Used by hook: 'customize_preview_init'
 *
 * @see add_action('customize_preview_init',$func)
 */
function symbiostock_customizer_live_preview()
{
    wp_enqueue_script(
            'symbiostock-themecustomizer',			//Give the script an ID
            get_template_directory_uri().'/js/customizer.js',//Point to file
            array( 'jquery','customize-preview' ),	//Define dependencies
            '',						//Define a version (optional)
            true						//Put script in footer?
    );
}
add_action( 'customize_preview_init', 'symbiostock_customizer_live_preview' );

?>
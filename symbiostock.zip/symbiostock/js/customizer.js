/**
 * This file adds some LIVE to the Theme Customizer live preview. To leverage
 * this, set your custom settings to 'postMessage' and then add your handling
 * here. Your javascript should grab settings from customizer controls, and 
 * then make any necessary changes to the page using jQuery.
 */
( function( $ ) {

	// Update the site title in real time...
	wp.customize( 'blogname', function( value ) {
		value.bind( function( newval ) {
			$( '#site-title a' ).html( newval );
		} );
	} );
	
	//Update the site description in real time...
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( newval ) {
			$( '.site-description' ).html( newval );
		} );
	} );

	//Update site title color in real time...
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( newval ) {
			$('#site-title a').css('color', newval );
		} );
	} );

	//Update site background color...
	wp.customize( 'background_color', function( value ) {
		value.bind( function( newval ) {
			$('body').css('background-color', newval );
		} );
	} );

	
	//Update widget background color...
	wp.customize( 'widget_background_color', function( value ) {
		value.bind( function( newval ) {
			$('.type-image .front-page-featured').css('background-color', newval );
		} );
	} );

	//Update link color...
	wp.customize( 'link_color', function( value ) {
		value.bind( function( newval ) {
			$('#content a:link').css('color', newval );
		} );
	} );

	//Update h color...
	wp.customize( 'h_color', function( value ) {
		value.bind( function( newval ) {
			$('h1, h2, h3, h4, h5, h6, h1 a:link, h2 a:link, h3 a:link, h4 a:link, h5 a:link, h6 a:link').css('color', newval );
		} );
	} );
	
	
	//Update p color...
	wp.customize( 'p_color', function( value ) {
		value.bind( function( newval ) {
			$('p').css('color', newval );
		} );
	} );
	
	
	//Update site title color in real time...
	wp.customize( 'symbiostock_options[link_textcolor]', function( value ) {
		value.bind( function( newval ) {
			$('a').css('color', newval );
		} );
	} );
	
} )( jQuery );
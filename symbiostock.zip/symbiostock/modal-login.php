<div id="symbiostock_member_modal" class="modal fade" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content panel panel-info">
       
            <div class="modal-header panel-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="panel-title" id="search_selection_title">Login / Register</h3>
            </div>
            <div class="modal-body panel-body">
            
            <?php include_once( 'register_symbiostock.php' ); ?>
            
            </div>
            <div class="modal-footer">  
                <a class="modal_control" aria-hidden="true" data-dismiss="modal" title="Close window" href="#"><i class="icon-remove"> &nbsp;</i></a>
            </div>
        </div>
    </div>
</div>
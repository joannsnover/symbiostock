<div id="symbiostock_member_modal" class="modal hide fade" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="search_selection_title">Login / Register</h3>
    </div>
    <div class="modal-body">
    
    <?php include_once('register_symbiostock.php'); ?>
    
    </div>
    <div class="modal-footer">  
        <a class="modal_control" aria-hidden="true" data-dismiss="modal" title="Close window" href="#"><i class="icon-remove"> &nbsp;</i></a>
    </div>
</div>
Welcome to Symbiostock, the wordpress theme for selling royalty free content, and networking with your fellow artists.

All communication and technical support for this project is presently hosted on microstockgroup.com:

http://www.microstockgroup.com/symbiostock/

Current project priorities:

1. Optimize image processing scripts to use less memory. This is for webmaster using more constrained hosting/environments.
2. A code cleanup and commenting run-through, pear standard, so a codex can be built.
3. For fun, users familiar with css should create / distribute some simple child themes to create a little style diversity.
4. Improve data validation and network interaction, so users cannot generate accidental errors.

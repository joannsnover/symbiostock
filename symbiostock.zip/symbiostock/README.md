Welcome to Symbiostock, the wordpress theme for selling royalty free content and networking with your fellow artists.

<strong>DOWNLOAD:</strong> https://github.com/orangeman555/symbiostock/blob/master/symbiostock.zip?raw=true

<strong>Child Theme:</strong> https://github.com/orangeman555/symbiostock/blob/master/symbiostock-child.zip?raw=true

All communication and technical support for this project is presently hosted on microstockgroup.com:

http://www.microstockgroup.com/symbiostock/
<hr />
<strong>IMPORTANT:</strong> This theme generally does not work on entry-level server environments due to its unique functions. <strong>Bluehost - <a href="http://www.bluehost.com/track/symbiostock">BLUEHOST.COM</a></strong> - seems to be the best option for Symbiostock deployments.

<h2>Current project priorities:</h2>

1. Optimize image processing scripts to use less memory. This is for webmaster using more constrained hosting/environments.
2. A code cleanup and commenting run-through, pear standard, so a codex can be built.
3. For fun, users familiar with css should create / distribute some simple child themes to create a little style diversity.
4. Improve data validation and network interaction, so users cannot generate accidental errors.

<h3>Symbiostock is currently in the testing phase. </h3>

You will notice you may want more features added. This is open source. They can be added! Please get more PHP developers involved in the project. I will add the most important features as they are agreed upon. For now, what we have is "base functionality" sufficient to a good start in testing.

<em>The Symbiostock community has blossomed</em>, and its very helpful to new users and people not greatly familiar with wordpress and direct selling of their work. Over the course of time please work together develop a Symbiostock <em>"Best Practice" and "Model Site"</em> standard together. Please share design strategies, child themes, and other useful things that will make the Symbiostock network successful. 

The most impressive aspect of Symbiostock isn't the theme, but the enthusiastic, hard working, helpful community that has surfaced. The rest is just details. 


Welcome to Symbiostock, the wordpress theme for selling royalty free content, and networking with your fellow artists.

Before you start using the theme, be sure to install the "Theme Updater" plugin:

http://wordpress.org/extend/plugins/theme-updater/

This will allow you to get automatic updates from github.

All communication and technical support for this project is presently hosted on http://www.microstockgroup.com:

http://www.microstockgroup.com/symbiostock/

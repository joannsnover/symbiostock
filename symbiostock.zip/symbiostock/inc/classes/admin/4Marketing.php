<?php
$networks = new network_manager();
$test = $networks->get_connected_networks( );

include_once(symbiostock_CLASSROOT . 'marketing/extended_network.php');
//include_once(symbiostock_CLASSROOT . 'marketing/network_hub.php');
//include_once(symbiostock_CLASSROOT . 'marketing/picturengine.php');
?>



<div class="">
<p>This is a temporary page while Symbiostock is in its early testing / development phase.</p>
<br />
<?php
phpinfo();
?>
</div>
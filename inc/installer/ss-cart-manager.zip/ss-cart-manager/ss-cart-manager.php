<?php
/*
Plugin Name: SYMBIOSTOCK - Cart Manager
Plugin URI: http://www.symbiostock.com/
Description: A cart manager plugin for Symbiostock. Improves customer service and control over carts and downloads.
Version: 1.1.5
Author: Leo Blanchette
Author URI: http://www.clipartillustration.com/
License: GPL2
*/

//Special thanks to reference found on http://stackoverflow.com/questions/12678177/how-to-create-gexf-from-php

//symbiostock must be activated, or bad things happen...


define( 'SSPATH', plugin_dir_path(__FILE__) );

define("symbiostock_remove_cap", true);

include_once('functions.php');

function symbiostock_cart_manager_ui(){
	
	?>
<div class="wrap">
    <div id="icon-tools" class="icon32"><br>
    </div>
    <h2>Cart Manager</h2>
    <p class="description">Manage carts on your site, help customers, and monitor cart activity.</p>
    <br />
    <?php ss_cart_manager_base_menu(); ?>
    <hr />
    
    <form method="post" action="">
        <?php
		$display_what = $_GET['ss_cm'];
		switch($display_what){
		
		case 'carts':
		
			ss_display_user_carts();
			
			break;

		case 'purchased':
		
			ss_display_user_purchases();
			
			break;

		case 'get_purchases':
		
			ss_display_user_files();
			
			break;				
										
			
		case 'get_cart':
		
			ss_display_user_cart();
			
			break;			
		
		default:
		
			echo '<p>Choose an action above...</p>';
		
			break;
		
		}
		
	?>
        
    <?php submit_button( 'Process', 'Submit', 'process_customer' ) ?>    
    </form>
    <hr />
    <h4>More info</h4>
    <br class="clear">
</div>
<?php
	
	}

add_action( 'admin_menu', 'ss_cart_manager', 99 );

function ss_cart_manager(){

	add_submenu_page( 'symbiostock-control-options', 'Cart Manager', 'Cart Manager', 'manage_options', 'symbiostock-cart-manager', 'symbiostock_cart_manager_ui' );

}

require_once('wp-updates-plugin.php');
new WPUpdatesPluginUpdater( 'http://wp-updates.com/api/1/plugin', 184, plugin_basename(__FILE__) );

?>

<?php
//write your functions below, they will be added to Symbiostock's functionality
//more on child theme function writing here: http://codex.wordpress.org/Child_Themes


?>
Special thanks to 9lives for making these! 

Profile: http://www.microstockgroup.com/profile/?u=1127

Website: http://www.clipartcandy.com/